/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package ui.main;

import data.DataStore;
import java.awt.CardLayout;
import java.io.IOException;
import javax.swing.JPanel;
import model.Community;
import model.PatientList;
import model.Person;
import static ui.main.Main.demo;
import ui.person.PersonInformationJPanel;
import ui.person.PersonInformationJPanel;

/**
 *
 * @author austinliu
 */
public class LogInJPanel extends javax.swing.JPanel {

    private JPanel userProcessContainer;
    private DataStore datastore;
    private PatientList pl;
    public LogInJPanel(JPanel upc,DataStore ds,PatientList patientlist){
        initComponents();
        userProcessContainer = upc;
        datastore =ds;
        pl= patientlist;
        cmbCity.removeAllItems();
        
    }
    /**
     * Creates new form MainJPanel
     */
    public LogInJPanel() {
        initComponents();
    }

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblCommunityChooser = new javax.swing.JLabel();
        cmbCity = new javax.swing.JComboBox<>();
        btnLogin = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        lblCommunityChooser.setFont(new java.awt.Font("Apple Braille", 0, 14)); // NOI18N
        lblCommunityChooser.setText("Community:");

        cmbCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0" }));
        cmbCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCityActionPerformed(evt);
            }
        });

        btnLogin.setText("Log in");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 0));
        jLabel1.setText("Have A Healthy Life!");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(lblCommunityChooser)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnLogin)
                            .addComponent(cmbCity, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(217, 217, 217)
                        .addComponent(jLabel1)))
                .addContainerGap(252, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel1)
                .addGap(66, 66, 66)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCommunityChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(btnLogin)
                .addContainerGap(129, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        int a=DataStore.getInstance().getCommunities().get(cmbCity.getSelectedIndex()).getId();
        
        PersonInformationJPanel vp = new PersonInformationJPanel(userProcessContainer,datastore,a,pl);
        userProcessContainer.add("Login", vp);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);       // TODO add your handling code here:
        
        
        
    }//GEN-LAST:event_btnLoginActionPerformed

    private void cmbCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCityActionPerformed
        // TODO add your handling code here:
        cmbCity.addItem("--choose--");    //向下拉列表中添加一项
        cmbCity.addItem("Community 1");
        cmbCity.addItem("Community 2");
        cmbCity.addItem("Community 3");
        cmbCity.addItem("Community 4");
        cmbCity.addItem("Community 5");
        cmbCity.addItem("Community 6");
        cmbCity.addItem("Community 7");
        cmbCity.addItem("Community 8");
        cmbCity.addItem("Community 9");
        cmbCity.addItem("Community 10");
        
    }//GEN-LAST:event_cmbCityActionPerformed

    public static void demo2() throws IOException{
        demo();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogin;
    private javax.swing.JComboBox<String> cmbCity;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblCommunityChooser;
    // End of variables declaration//GEN-END:variables
}
