/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui.main;

import data.DataGenerator;
import data.DataReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;
import data.DataStore;
import java.util.List;
import model.Community;
import model.Encounter;
import model.Person;

/**
 *
 * @author austinliu
 */
public class Main{
    DataReader personReader;
    DataReader encounterReader;
    DataReader communityReader;
    List<Community> communities;
    List<Person> persons;
    List<Encounter> encounters;
    
    // AnalysisHelper helper;

    public Main() throws IOException{
        DataGenerator generator = DataGenerator.getInstance();
        personReader = new DataReader(generator.getPersonFilePath());
        encounterReader = new DataReader(generator.getEncounterPath());
        communityReader = new DataReader(generator.getCommunityFilePath());
        // helper = new AnalysisHelper();
        
        
    }

    /**
     * @param args the command line arguments
     */
    public static DataStore demo() throws IOException {
        Main inst = new Main();
        DataStore ds = new DataStore();
        ds = inst.readData();
        
        return ds;
    }


    private DataStore readData() throws IOException{
        String[] row;
        
        DataStore rd = new DataStore();
        while((row = encounterReader.getNextRow()) != null ){
            generateEncounter(row);
        }
        while((row = personReader.getNextRow()) != null ){
            generatePerson(row);
        }
        while((row = communityReader.getNextRow()) != null ){
            generateCommunity(row);
}
        return rd;
    }

    private Community generateCommunity(String[] row){
        int id = Integer.parseInt(row[0]);
        Community c = new Community(id,row[1]);
        DataStore.getInstance().getCommunities().put(id,c);
        
       Map<Integer,Person> persons = DataStore.getInstance().getPersons();
       for(Person p:persons.values()){
           if(p.getCommunityid() == c.getId()){
               c.createPerson(p.getID(),p.getCommunityid(), p.getAge(), p.getFirstName(), p.getLastName(), p.getHouse());
           }
       }
       return c;
    }

    private Person generatePerson(String[] row){
        int personId = Integer.parseInt(row[0]);
        int communityId = Integer.parseInt(row[1]);
        int age = Integer.parseInt(row[4]);
        Person person = new Person(personId,communityId,age,row[2], row[3],row[5]);
        DataStore.getInstance().getPersons().put(personId, person);  
         
        Map<Integer, Encounter> encounters = DataStore.getInstance().getEncounters();
        
        for(Encounter e:encounters.values()){
            
            if(e.getPersonID() == person.getID()){
                
                person.createEncounter(e.getId(), e.getPersonID(),e.getDate(),e.getSBP(),e.getDBP());
            }
        }
        
        return person;
    }

    private Encounter generateEncounter(String[] row){
        int encounterId = Integer.parseInt(row[0]);
        int personId = Integer.parseInt(row[1]);
        LocalDate date = LocalDate.parse(row[2]);
        Double SBP = Double.parseDouble(row[3]);
        Double DBP = Double.parseDouble(row[4]);

        Encounter e = new Encounter(encounterId,personId,date, SBP, DBP);
        DataStore.getInstance().getEncounters().put(encounterId, e);

        return e;
    }
}
