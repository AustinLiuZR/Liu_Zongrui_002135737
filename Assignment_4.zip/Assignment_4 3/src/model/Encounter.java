package model;

import java.time.LocalDate;

/**
 *
 * @author austinliu
 */
public class Encounter {
    private int personID;
    private int encounterid;
    private LocalDate date;
    private Double SBP;
    private Double DBP;

    public Encounter(int id,int personID, LocalDate date, Double SBP, Double DBP){
        this.setPersonID(personID);
        this.setId(id);
        this.setDate(date);
        this.setSBP(SBP);
        this.setDBP(DBP);
    }


    public int getPersonID() {
        return personID;
    }


    public void setPersonID(int personID) {
        this.personID = personID;
    }


    public Double getDBP() {
        return DBP;
    }

    public void setDBP(Double dBP) {
        this.DBP = dBP;
    }

    public Double getSBP() {
        return SBP;
    }

    public void setSBP(Double sBP) {
        this.SBP = sBP;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public int getId() {
        return encounterid;
    }

    public void setId(int id) {
        this.encounterid = id;
    }
}
