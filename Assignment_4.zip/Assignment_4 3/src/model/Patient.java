package model;

import java.time.LocalDate;

/**
 *
 * @author austinliu
 */
public class Patient {
    private int personId;
    private String firstname;
    private String lastname;
    private int age;
    private String house;

    public Patient(int personId, String firstname, String lastname, int age, String house) {
        this.personId = personId;
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
        this.house = house;
    }

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }
    
    @Override
    public String toString() {
        return "Patient{" + "ID = " + personId + '}';
    }

}