/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author austinliu
 */
public class Person {
    private int communityid;
    private int personid;
    private int age;
    private String firstName;
    private String lastName;
    private String house;
    private List<Encounter> encounterCatalog;

    public Person(int id,int communityid,int age, String firstName, String lastName, String house) {
        this.communityid = communityid;
        this.personid = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.house = house;
        this.age = age;
        this.encounterCatalog = new ArrayList<Encounter>();
    }

    public Person() {
         //To change body of generated methods, choose Tools | Templates.
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getCommunityid() {
        return communityid;
    }

    public void setCommunityid(int communityid) {
        this.communityid = communityid;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public List<Encounter> getEncounter() {
        return encounterCatalog;
    }

    public void setEncounter(List<Encounter> encounter) {
        this.encounterCatalog = encounter;
    }
    public Encounter createEncounter(int id,int personID, LocalDate date, Double SBP, Double DBP){
        Encounter e = new Encounter(id,personID,date, SBP, DBP);
        encounterCatalog.add(e);
        return e;
    }

    public void deleteEncounter(Encounter e){
        encounterCatalog.remove(e);
    }

    public Encounter searchEncounter(int id){
        
        for (Encounter e : encounterCatalog) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getID() {
        return personid;
    }

    public void setID(int id) {
        this.personid = id;
    }
    
    @Override
    public String toString() {
        return "Person{" + "ID = " + personid + ", firstName = " + 
        firstName + ", lastName = " + lastName + 
        ", no. of encounters = " + encounterCatalog.size() + '}';
    }
}
