
package model;

import java.awt.Image;
import java.util.List;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author austinliu
 */
public class Community {
    private List<Person> personCatalog;
    private int Communityid;
    private String City;

    public Community(int Communityid, String City){
        personCatalog = new ArrayList<Person>();
        this.Communityid = Communityid;
        
        this.City = City;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        this.City = city;
    }


    public int getId() {
        return Communityid;
    }

    public void setId(int id) {
        this.Communityid = id;
    }

    public List<Person> getPersonCatalog() {
        return personCatalog;
    }

    public Person createPerson(int communityid, int id, int age, String firstName, String lastName, String house){
        Person p = new Person(communityid, id, age, firstName, lastName, house);
        personCatalog.add(p);
        return p;
    }

    public void deletePerson(Person p){
        personCatalog.remove(p);
    }

    public Person searchPerson(int id){
        
        for (Person person : personCatalog) {
            if (person.getID() == id) {
                return person;
            }
        }
        return null;
    }
}
