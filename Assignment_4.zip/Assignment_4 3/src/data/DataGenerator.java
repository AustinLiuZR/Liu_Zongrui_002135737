/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Random;

/**
 *
 * @author austinliu
 */
public class DataGenerator {
     private static DataGenerator instance;
    
    private FileWriter writer;
    private File file;
    private final Random rand;
    private final int personIdsRange;
    private final int encounterIdsRange;
    private final int communityIdsRange;



    private final String ENCOUNTER_HEADER = "EncounterId,PersonId,Date,SBP,DBP";
    private final String PERSON_HEADER = "PersonId,CommunityId,First-Name,Last-Name,age,house";
    private final String COMMUNITY_HEADER = "Community-Id,City";
    private final String PATIENT_HEADER = "PersonId,First-Name,Last-Name,Age,House";
    private final String LINE_BREAK = "\n";
    
    private final String PERSON_PATH = "./Peron.csv";
    private final String ENCOUNTER_PATH = "./Encounter.csv";
    private final String COMMUNITY_PATH = "./Community.csv";
    private final String PATIENT_PATH = "./Patient.csv";
    
    
    
    private DataGenerator() throws IOException {
                
        rand = new Random();
        
        personIdsRange = 50;
        encounterIdsRange = 200;
        communityIdsRange = 10;
        
        generateEncounterFile();
        generatePersonFile();
        generateCommunityFile();
        
    }
    
    public static DataGenerator getInstance() throws IOException{
        if(instance == null)
        {
            instance = new DataGenerator();
        }
        return instance;
    }

    
    private void generateCommunityFile() throws IOException{
        //generate Order file
        try {
            file = new File(COMMUNITY_PATH);
            if(file.exists()){
                file.delete();
            }
            file.createNewFile();
            writer = new FileWriter(file);
        
            writer.append(COMMUNITY_HEADER);
            writer.append(LINE_BREAK);
            
            generateCommunityColumns();   
        }finally{
            try {
                writer.flush();
                writer.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }
        }
        
    }
    
    private void generateCommunityColumns() throws IOException{
        int communityId = 1;
        
        //the loop for orders
        while(communityId <= communityIdsRange ) {
            
                int cityId = rand.nextInt(10);
                String house = "City "+cityId;
                
                String column = communityId + ","+house;
                
                writer.append(column);
                writer.append(LINE_BREAK);
                
                communityId++;
            
            

        }
        
    }

    private void generateEncounterFile() throws IOException{
        //generate Order file
        try {
            file = new File(ENCOUNTER_PATH);
            if(file.exists()){
                file.delete();
            }
            file.createNewFile();
            writer = new FileWriter(file);
        
            writer.append(ENCOUNTER_HEADER);
            writer.append(LINE_BREAK);
            
            generateEncounterColumns();   
            
        }finally{
            try {
                writer.flush();
                writer.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }
        }
        
        
        
    }
    
    public LocalDate between(int y1,int m1,int d1,int y2,int m2, int d2) {
        Random random = new Random();
        int minDay = (int) LocalDate.of(y1,m2,d1).toEpochDay();
        int maxDay = (int) LocalDate.of(y2,m2,d2).toEpochDay();
        long randomDay = minDay + random.nextInt(maxDay - minDay);

        LocalDate randomDate = LocalDate.ofEpochDay(randomDay);
        return randomDate;
    }
    

    private void generateEncounterColumns() throws IOException{
        int encounterId = 1;
        
        while(encounterId <= encounterIdsRange ) {

                int SBP = rand.nextInt(40)+110;
                int DBP = rand.nextInt(15)+75;
                LocalDate date = between(2019,2,20,2021,10,27);
                int personId = rand.nextInt(personIdsRange)+1;

                String column = encounterId + ","+ personId + "," + date + "," + SBP + "," + DBP;
                
                writer.append(column);
                writer.append(LINE_BREAK);
                
                encounterId++;
    
        }
        
    }

    private void generatePersonFile() throws IOException{
        //generate Product file
        
        try {
            
            file = new File(PERSON_PATH);
            if(file.exists()){
                file.delete();
            }
            file.createNewFile();
            writer = new FileWriter(file);
        
            writer.append(PERSON_HEADER);
            writer.append(LINE_BREAK);
        
            generatePersonColumns();   
            
        }finally{
            
            try {
                writer.flush();
                writer.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }
        }
        
        
    }
    
    private void generatePersonColumns() throws IOException{
        int personId = 1;
        
        //the loop for orders
        while(personId <= personIdsRange ){
            //items for a order.
            int age = rand.nextInt(100);
            String firstName = "FirstName "+personId;
            String lastName = "LastName "+personId;
            String house = "House "+personId;
            int communityId = rand.nextInt(communityIdsRange)+1;
            String column = personId + "," + communityId+"," + firstName +","+lastName + "," + age +","+house;
                
            writer.append(column);
            writer.append(LINE_BREAK);
                        
            personId++;
        }
        
    }
    
    public String getEncounterPath(){
        return ENCOUNTER_PATH;
    }
    
    public String getPersonFilePath(){
        return PERSON_PATH;
    }
    public String getCommunityFilePath(){
        return COMMUNITY_PATH;
    }
    
}
