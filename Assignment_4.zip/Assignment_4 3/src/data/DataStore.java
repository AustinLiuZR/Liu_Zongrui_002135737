/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Community;
import model.Encounter;
import model.Patient;
import model.Person;

/**
 *
 * @author austinliu
 */
public final class DataStore {
    private static DataStore dataStore;
    
    private Map<Integer, Person> persons;
    private Map<Integer, Encounter> encounters;
    private Map<Integer, Community> communities;
    
    
    
    public DataStore(){
        setPersons(new HashMap<>());
        setEncounters(new HashMap<>());
        setCommunities(new HashMap<>());
    }


    public Map<Integer, Community> getCommunities() {
        return communities;
    }

    public void setCommunities(Map<Integer, Community> communities) {
        this.communities = communities;
    }
    
     public Map<Integer, Person> getPersons() {
        return persons;
    }

    public void setPersons(Map<Integer, Person> persons) {
        this.persons = persons;
    }
    
    public Map<Integer, Encounter> getEncounters() {
        return encounters;
    }

    public void setEncounters(Map<Integer, Encounter> encounters) {
        this.encounters = encounters;
    }

  
    

    public static DataStore getInstance(){
        if(dataStore == null)
            dataStore = new DataStore();
        return dataStore;
    }

    public static DataStore getDataStore() {
        return dataStore;
    }

    public static void setDataStore(DataStore dataStore) {
        DataStore.dataStore = dataStore;
    }



}
