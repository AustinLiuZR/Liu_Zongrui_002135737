/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Restaurant;

import java.util.ArrayList;

/**
 *
 * 
 */
public class RestaurantDirectory {
    private ArrayList<Restaurant> restaurantList;
    private ArrayList<Menu> ml;
    public RestaurantDirectory(){
        restaurantList = new ArrayList();
        ml = new ArrayList();
    }
    
      public ArrayList<Menu> getMl() {
        return ml;
    }

    public void setMl(ArrayList<Menu> ml) {
        this.ml = ml;
    }
    
    public void createMenu(String name,Double price,String describe){
        Menu m = new Menu(name,price,describe);
        ml.add(m);
    }
    
    public void deleteMenu(Menu m){
        ml.remove(m);
    }
    public ArrayList<Restaurant> getRestaurantList(){
        return restaurantList;
    }
    
    public Restaurant authenticateUser(String username, String password){
        for(Restaurant r : restaurantList)
            if(r.getUsername().equals(username) && r.getPassword().equals(password)){
                return r;
            }
        return null;
    }
    
    public Restaurant createRestaurant(int ID, String Name, String username, String password){
        Restaurant r = new Restaurant(ID, Name, username, password);
        
        restaurantList.add(r);
        return r;
    }
    
    public boolean checkIfUsernameIsUnique(String username){
        for(Restaurant r : restaurantList){
            if(r.getUsername().equals(username))
                return false;
        }
    return true;
    }
}
