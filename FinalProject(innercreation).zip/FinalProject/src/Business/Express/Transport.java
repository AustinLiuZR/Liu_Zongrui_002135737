/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.Express;

import Business.Employee.Employee;
import Business.Role.Role;
import Business.WorkQueue.WorkQueue;

/**
 *
 * @author 13522
 */
public class Transport {
    private int ID;
    private String Name;
    private String username;
    private String password;
    private Employee employee;
    private Role role;
    private WorkQueue workQueue;
}
