/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Restaurant;

import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class RestaurantDirectory {
    private ArrayList<Restaurant> restaurantList;
    public RestaurantDirectory(){
        restaurantList = new ArrayList();
    }
    public ArrayList<Restaurant> getRestaurantList(){
        return restaurantList;
    }
    
    public Restaurant authenticateUser(String username, String password){
        for(Restaurant r : restaurantList)
            if(r.getUsername().equals(username) && r.getPassword().equals(password)){
                return r;
            }
        return null;
    }
    
    public Restaurant createRestaurant(int ID, String Name, String username, String password){
        Restaurant r = new Restaurant(ID, Name, username, password);
        
        restaurantList.add(r);
        return r;
    }
    
    public boolean checkIfUsernameIsUnique(String username){
        for(Restaurant r : restaurantList){
            if(r.getUsername().equals(username))
                return false;
        }
    return true;
    }
}
