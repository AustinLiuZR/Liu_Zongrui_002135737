/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author archil
 */
public class Uber {

    private String manufacName;
    private int proYear;
    private int uberNum;
    private int seatNum;
    private int modNum;
    private String city;
    private String certi;
    private String updatedTime;
    private String avail ="Available";

    public String getAvail() {
        return avail;
    }

    public void setAvail(String avail) {
        this.avail = avail;
    }    
            
    public String getCerti() {
        return certi;
    }

    public void setCerti(String certi) {
        this.certi = certi;
    }

    public int getSeatNum() {
        return seatNum;
    }

    public void setSeatNum(int seatNum) {
        this.seatNum = seatNum;
    }

    public int getModNum() {
        return modNum;
    }

    public void setModNum(int modNum) {
        this.modNum = modNum;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Uber.count = count;
    }
    
    private static int count = 0;

    @Override
    public String toString() {
        return manufacName; //To change body of generated methods, choose Tools | Templates.
    }

    public Uber() {
        count++;
        uberNum = count;
    }

    public String getProdName() {
        return manufacName;
    }

    public void setProdName(String prodName) {
        this.manufacName = prodName;
    }

    public int getPrice() {
        return proYear;
    }

    public void setPrice(int price) {
        this.proYear = price;
    }

    public int getModelNumber() {
        return uberNum;
    }

    public void setModelNumber(int modelNumber) {
        this.uberNum = modelNumber;
    }

}
