/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author archil
 */
public class UberCatalog {

    private List<Uber> productCatalog;

    public UberCatalog() {
        productCatalog = new ArrayList<Uber>();
    }

    public List<Uber> getProductcatalog() {
        return productCatalog;
    }

    public Uber addProduct() {
        Uber p = new Uber();
        productCatalog.add(p);
        return p;
    }

    public void removeProduct(Uber p) {
        productCatalog.remove(p);
    }

    public Uber searchProduct(int id) {
        for (Uber product : productCatalog) {
            if (product.getModelNumber() == id) {
                return product;
            }
        }
        return null;
    }
}
