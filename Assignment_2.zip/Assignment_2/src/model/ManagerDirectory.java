/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author archil
 */
public class ManagerDirectory {

    private List<Manager> supplierList;

    public ManagerDirectory() {
        supplierList = new ArrayList<Manager>();
    }

    public List<Manager> getSupplierlist() {
        return supplierList;
    }

    public Manager addSupplier() {
        Manager newSupplier = new Manager();
        supplierList.add(newSupplier);
        return newSupplier;
    }

    public void removeSupplier(Manager s) {
        supplierList.remove(s);
    }

    public Manager searchSupplier(String supplierName) {
        for (Manager supplier : supplierList) {
            if (supplier.getSupplyName().equals(supplierName)) {
                return supplier;
            }
        }
        return null;
    }

    public Object getProductCatalog() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
