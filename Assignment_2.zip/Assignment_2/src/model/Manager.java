/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author archil
 */
public class Manager {

    private String supplyName;
    private UberCatalog productCatalog;

    public Manager() {
        productCatalog = new UberCatalog();
    }

    public String getSupplyName() {
        return supplyName;
    }

    public void setSupplyName(String supplyName) {
        this.supplyName = supplyName;
    }

    public UberCatalog getProductCatalog() {
        return productCatalog;
    }

    public void setProductCatalog(UberCatalog productCatalog) {
        this.productCatalog = productCatalog;
    }

    @Override
    public String toString() {
        return supplyName; 
        
    }


}
