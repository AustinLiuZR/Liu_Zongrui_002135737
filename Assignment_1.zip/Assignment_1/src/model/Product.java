/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author austinliu
 */
public class Product {
    
    private String name;
    private String geographicData;
    private String dateOfBirth;
    private String telephoneNum;
    private String faxNum;
    private String emailAdd;
    private String ssNum;
    private String mrNum;
    private String hpbNum;
    private String baNum;
    private String clNum;
    private String visNum;
    private String disNum;
    private String linkedin;
    private String ipAdd;
    private String uiNum;
    private ImageIcon bioId;
    private ImageIcon fullFacePhoto;
    

    public ImageIcon getBioId() {
        return bioId;
    }

    public void setBioId(ImageIcon bioId) {
        this.bioId = bioId;
    }

    public ImageIcon getFullFacePhoto() {
        return fullFacePhoto;
    }

    public void setFullFacePhoto(ImageIcon fullFacePhoto) {
        this.fullFacePhoto = fullFacePhoto;
    }
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGeographicData() {
        return geographicData;
    }

    public void setGeographicData(String geographicData) {
        this.geographicData = geographicData;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getTelephoneNum() {
        return telephoneNum;
    }

    public void setTelephoneNum(String telephoneNum) {
        this.telephoneNum = telephoneNum;
    }

    public String getFaxNum() {
        return faxNum;
    }

    public void setFaxNum(String faxNum) {
        this.faxNum = faxNum;
    }

    public String getEmailAdd() {
        return emailAdd;
    }

    public void setEmailAdd(String emailAdd) {
        this.emailAdd = emailAdd;
    }

    public String getSsNum() {
        return ssNum;
    }

    public void setSsNum(String ssNum) {
        this.ssNum = ssNum;
    }

    public String getMrNum() {
        return mrNum;
    }

    public void setMrNum(String mrNum) {
        this.mrNum = mrNum;
    }

    public String getHpbNum() {
        return hpbNum;
    }

    public void setHpbNum(String hpbNum) {
        this.hpbNum = hpbNum;
    }

    public String getBaNum() {
        return baNum;
    }

    public void setBaNum(String baNum) {
        this.baNum = baNum;
    }

    public String getClNum() {
        return clNum;
    }

    public void setClNum(String clNum) {
        this.clNum = clNum;
    }

    public String getVisNum() {
        return visNum;
    }

    public void setVisNum(String visNum) {
        this.visNum = visNum;
    }

    public String getDisNum() {
        return disNum;
    }

    public void setDisNum(String disNum) {
        this.disNum = disNum;
    }

    public String getLinkedin() {
        return linkedin;
    }

    public void setLinkedin(String linkedin) {
        this.linkedin = linkedin;
    }

    public String getIpAdd() {
        return ipAdd;
    }

    public void setIpAdd(String ipAdd) {
        this.ipAdd = ipAdd;
    }

    public String getUiNum() {
        return uiNum;
    }

    public void setUiNum(String uiNum) {
        this.uiNum = uiNum;
    }
    
    
    
}
