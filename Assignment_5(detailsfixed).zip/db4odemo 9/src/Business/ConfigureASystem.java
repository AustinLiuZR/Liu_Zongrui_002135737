package Business;

import Business.Customer.Customer;
import Business.Customer.CustomerDirectory;
import Business.DeliveryMan.DeliveryMan;
import Business.DeliveryMan.DeliveryManDirectory;
import Business.Employee.Employee;
import Business.Restaurant.Restaurant;
import Business.Restaurant.RestaurantDirectory;
import Business.Role.AdminRole;
import Business.Role.CustomerRole;
import Business.Role.DeliverManRole;
import Business.Role.SystemAdminRole;
import Business.UserAccount.UserAccount;

/**
 *
 * 
 */
public class ConfigureASystem {
        
    public static EcoSystem configure(){
        
        EcoSystem system = EcoSystem.getInstance();
        
        //Create a network
        //create an enterprise
        //initialize some organizations
        //have some employees 
        //create user account
        
        
        Employee employee = system.getEmployeeDirectory().createEmployee("RRH");
        Employee e1 = system.getEmployeeDirectory().createEmployee("CP");
        Employee e2 = system.getEmployeeDirectory().createEmployee("CX");
        Employee e3 = system.getEmployeeDirectory().createEmployee("CM");
        system.getUserAccountDirectory().createUserAccount("sysadmin", "sysadmin", employee, new SystemAdminRole());
        system.getUserAccountDirectory().createUserAccount("1", "1", e1, new CustomerRole());
        system.getUserAccountDirectory().createUserAccount("2","2", e2, new DeliverManRole());
        system.getUserAccountDirectory().createUserAccount("3","3", e3, new AdminRole());
//        
        Customer c1 = system.getCustomerDirectory().createCustomer(1, "Name", "username", "password");
        DeliveryMan m1 = system.getDeliveryManDirectory().createDeliveryMan(2, "Name", "username", "password");
        system.getRestaurantDirectory().createRestaurant(3, "1", "2", "3");
//      Restaurant r1 = system.getRestaurantDirectory().createRestaurant(3, "Name", "username", "password");
        
        return system;
    }
    
}
